use negocio;

INSERT INTO clientes (nombre, apellido, estado_civil, cuit, direccion,telefono,email,comentarios) 
VALUES 
('Cristan', 'Vidal', 'SOLTERO', '2904534', 'avenida medrano 785','115548101','aras@gmail.com','Cliente 01'), 
('Roberto', 'Suarez', 'CASADO', '2346566', 'Franco 2224','1154561101','agas@gmail.com','Cliente 02'),  
('Juan', 'Moreno', 'VIUDO', '5435263', 'Carlos Lopez 3536','115544561','rasa@gmail.com','Cliente 03'),
('Emilio', 'Fernandez', 'VIUDO', '3523565', 'Emilio Lamarca 4568','156220665','zasa@gmail.com','Cliente 04'),
('Arturo', 'Losada', 'DIVORCIADO', '2353255', 'Juan Lopez 2456','115789561','rta@gmail.com','Cliente 05');

INSERT INTO articulos (descripcion, rubro, costo, precio, stock,stock_minimo,stock_maximo) 
VALUES 
('Leche', 'LACTEOS', '45', '70', '6','4','20'), 
('Medialunas', 'PANADERIA', '15', '24', '40','10','100'),  
('Jabon', 'LIMPIEZA', '45', '100', '20','10','40'), 
('Queso', 'FIAMBRES', '24', '50', '19','8','20'), 
('Fernet', 'BEBIDAS', '300', '600', '15','10','30');


INSERT INTO facturas (letra, numero, fecha, monto, forma_de_pago,id_cliente) 
VALUES 
('A', '1', '2020-03-25', '300', 'EFECTIVO',1), 
('B', '2', '2020-12-02', '500', 'EFECTIVO',2),  
('C', '1', '2020-06-12', '160', 'TARJETA',3),
('S', '6', '2020-09-18', '480', 'DEBITO',4),
('Q', '2', '2020-09-07', '246', 'CHEQUE',5);


INSERT INTO detalles (id_factura, id_articulo, cantidad, precio_unitario) 
VALUES 
(1, 2, 12, 50), 
(2, 3, 5, 100 ),  
(3, 1, 6, 120 ),
(4, 5, 8, 120),
(5, 4, 3, 80);


insert into clientes (nombre,apellido,estado_civil,cuit,direccion,telefono,email,comentarios) values
('Marta','Gomez','SOLTERO',42102443,'Av siempre viva 321','48654982','Martita@gmail.com','Hola soy Marta Gomez'),
('Maite','Garcia','CASADO',5869230,'Lopez de vega 153','45620331','MaiteCrisis@hotmail.com','Hola soy Maite'),
('Martin','Camacho','VIUDO',2563321,'Pasco 1233','40208965','MartinEze@gmail.com','Hola soy Camacho'),
('Ermelinda','Yaccuzzi','DIVORCIADO',3625177,'AV.Entre Rios 1633','46597946','YaccuErme@gmail.com','Hola soy Ermelinda'),
('Jose','Santos','SOLTERO',51635,'Gorriti 4564','JosePedrol@gmail.com','45613975','Hola soy Santos');

insert into articulos(descripcion,rubro,costo,precio,stock,stock_minimo,stock_maximo) VALUES
('Coca Cola','BEBIDAS',50,250,100,0,500),
('Jamon Natural 42','FIAMBRES',10,130,20,0,200),
('Pan Lactal','PANADERIA',5,300,20,2,100), 
('Detergente','LIMPIEZA ',200,500,56,10,1000),
('Chorizo','CARNICERIA',150,300,15,0,500);

INSERT into facturas(letra,numero,fecha,monto,forma_de_pago,id_cliente) VALUES
('A',135789,'2022/05/20',1000,'EFECTIVO',2),
('A',135159,'2021/10/12',2000,'EFECTIVO',5),
('A',135147,'2020/08/30',5000,'TARJETA',3),
('A',135963,'2019/04/18',4500,'DEBITO',1),
('A',135322,'2020/11/27',3500,'CHEQUE',4);

INSERT into detalles(id_factura,id_articulo,cantidad,precio_unitario) VALUES
(6,1,50,5000),
(6,4,10,200),
(7,2,30,6000),
(8,3,400,2000),
(9,2,150,3500);

-- Insert para la tabla clientes

INSERT INTO clientes (nombre, apellido, estado_civil, cuit, direccion, telefono, email, comentarios)
VALUES ('Sol', 'Erichsen', 'SOLTERO', '40069876', 'Medrano 564', '12345678', 'lilicoes@gmail.com', 'minorista');

INSERT INTO clientes (nombre, apellido, estado_civil, cuit, direccion, telefono, email, comentarios)
VALUES ('Maria', 'Bardalez', 'DIVORCIADO', '09876678', 'Aguero 675', '87654321', 'mimofest@gmail.com', 'mayorista');

INSERT INTO clientes (nombre, apellido, estado_civil, cuit, direccion, telefono, email, comentarios)
VALUES ('Julieta', 'Garcia', 'VIUDO', '54322347', 'Urquiza 890', '56776543', 'lucio@gmail.com', 'minorista');

INSERT INTO clientes (nombre, apellido, estado_civil, cuit, direccion, telefono, email, comentarios)
VALUES ('Violeta', 'Luque', 'CASADO', '40067654', 'Alsina 543', '09888907', 'violet@gmail.com', 'mayorista');

INSERT INTO clientes (nombre, apellido, estado_civil, cuit, direccion, telefono, email, comentarios)
VALUES ('Julio', 'Wolf', 'SOLTERO', '40061234', 'Juan B Justo 123', '76578980', 'juli@gmail.com', 'minorista');


-- Insert para la tabla facturas 

INSERT INTO facturas (letra, numero, fecha, monto, forma_de_pago, id_cliente)
VALUES ('A', 123, '2010-08-12', 4008, 'TARJETA', 1);

INSERT INTO facturas (letra, numero, fecha, monto, forma_de_pago, id_cliente)
VALUES ('B', 345, '1999-04-11', 5007, 'EFECTIVO', 2);

INSERT INTO facturas (letra, numero, fecha, monto, forma_de_pago, id_cliente)
VALUES ('C', 567, '2014-09-12', 3226, 'EFECTIVO', 3);

INSERT INTO facturas (letra, numero, fecha, monto, forma_de_pago, id_cliente)
VALUES ('A', 876, '2010-02-12', 4536, 'EFECTIVO', 4);

INSERT INTO facturas (letra, numero, fecha, monto, forma_de_pago, id_cliente)
VALUES ('B', 989, '2020-06-14', 7779, 'TARJETA', 5);


-- Insert para la tabla articulos

INSERT INTO articulos (descripcion, rubro, costo, precio, stock, stock_minimo, stock_maximo)
VALUES ('Coca-Cola', 'BEBIDAS', 100, 122, 7, 1, 67);

INSERT INTO articulos (descripcion, rubro, costo, precio, stock, stock_minimo, stock_maximo)
VALUES ('Papel', 'PERSONAL', 200, 222, 5, 1, 54);

INSERT INTO articulos (descripcion, rubro, costo, precio, stock, stock_minimo, stock_maximo)
VALUES ('Escoba', 'LIMPIEZA', 300, 333, 4, 1, 44);

INSERT INTO articulos (descripcion, rubro, costo, precio, stock, stock_minimo, stock_maximo)
VALUES ('Torta', 'PANADERIA', 400, 456, 3, 1, 22);

INSERT INTO articulos (descripcion, rubro, costo, precio, stock, stock_minimo, stock_maximo)
VALUES ('Crema', 'LACTEOS', 340, 877, 3, 1, 33);

-- Insert para la tabla detalles
 
INSERT INTO detalles (id_factura, id_articulo, cantidad, precio_unitario)
VALUES (1, 5, 12, 124);

INSERT INTO detalles (id_factura, id_articulo, cantidad, precio_unitario)
VALUES (2, 4, 23, 234);

INSERT INTO detalles (id_factura, id_articulo, cantidad, precio_unitario)
VALUES (3, 3, 43, 323);

INSERT INTO detalles (id_factura, id_articulo, cantidad, precio_unitario)
VALUES (4, 2, 14, 123);

INSERT INTO detalles (id_factura, id_articulo, cantidad, precio_unitario)
VALUES (5, 1, 24, 222);


insert  into clientes(nombre, apellido, estado_civil ,cuit,direccion,telefono,email,comentarios)
values ('Mariano','Diaz','SOLTERO','23458462','Medrano 234','1152752047','MarianoD@hmail.com','Okey'); 
insert  into clientes(nombre, apellido, estado_civil ,cuit,direccion,telefono,email,comentarios)
values ('Luciana','Repollo','CASADO','225352162','Murguiondo 2152','1132742077','Lu@hotmail.com','Gracias'); 
insert  into clientes(nombre, apellido, estado_civil ,cuit,direccion,telefono,email,comentarios)
values ('Florencia','Moretti','SOLTERO','23118462','inclan 1763','1121753047','Flor@gmail.com','Bueno'); 
insert  into clientes(nombre, apellido, estado_civil ,cuit,direccion,telefono,email,comentarios)
values ('Melanie','Recaño','SOLTERO','26643262','Curapaligue 1234','1122753147','MelR@gmail.com','Nos vemos'); 
insert  into clientes(nombre, apellido, estado_civil ,cuit,direccion,telefono,email,comentarios)
values ('Gabriela','Manchini','SOLTERO','21424422','Av.diaz.velez3424','1152112047','GabrielaD@gmail.com','Me voy');

insert  into facturas(letra, numero, fecha,monto,forma_de_pago,id_cliente)
values ('A','133646433','2021-12-08',253.00,'Tarjeta','4');
insert  into facturas(letra, numero, fecha,monto,forma_de_pago,id_cliente)
values ('B','124442433','2019-09-07',15.300,'Efectivo','1');
insert  into facturas(letra, numero, fecha,monto,forma_de_pago,id_cliente)
values ('B','133636433','2021-12-08',12.000,'Debito','2');
insert  into facturas(letra, numero, fecha,monto,forma_de_pago,id_cliente)
values ('A','133236433','2016-11-07',8.300,'Cheque','2');
insert  into facturas(letra, numero, fecha,monto,forma_de_pago,id_cliente)
values ('C','122346433','2018-05-02',21.200,'Efectivo','5');
insert into articulos(descripcion, rubro, costo, precio, stock, stock_maximo, stock_minimo)
values ('Pepsi','Bebidas',180,180,'8','10','4');
insert into articulos(descripcion, rubro, costo, precio, stock, stock_maximo, stock_minimo)
values ('Serenisima','Lacteos',180,180,'4','9','2');
insert into articulos(descripcion, rubro, costo, precio, stock, stock_maximo, stock_minimo)
values ('Escoba','Limpieza',250,250,'5','8','3');
insert into articulos(descripcion, rubro, costo, precio, stock, stock_maximo, stock_minimo)
values ('Pan duro','Panaderia',450,450,'9','11','7');
insert into articulos(descripcion, rubro, costo, precio, stock, stock_maximo, stock_minimo)
values ('Chinchulin','Carniceria',300,300,'3','9','2');
insert into detalles(id_factura,id_articulo,cantidad, precio_unitario)
values('2','23','4',180.232);
insert into detalles(id_factura,id_articulo,cantidad, precio_unitario)
values('3','24','3',180.121);
insert into detalles(id_factura,id_articulo,cantidad, precio_unitario)
values('3','21','2',250.123);
insert into detalles(id_factura,id_articulo,cantidad, precio_unitario)
values('4','23','6',450.321);
insert into detalles(id_factura,id_articulo,cantidad, precio_unitario)
values('3','22','1',300.322);


insert into clientes (nombre,apellido,estado_civil,cuit,direccion,telefono,email,comentarios) values('Raul','Fernandez','SOLTERO','20547503','Pringles 122','44445555','raulfernandez@gmail.com','cliente frecuente');
insert into clientes (nombre,apellido,estado_civil,cuit,direccion,telefono,email,comentarios) values('Pedro','Gomez','CASADO','301234318','Sucre 235','55556666','pedrogomez@gmail.com','cliente unico');
insert into clientes (nombre,apellido,estado_civil,cuit,direccion,telefono,email,comentarios) values('Cristian','Perez','VIUDO','240292408','Sarmiento 1234','11112222','cristianperez@gmail.com','deudor');
insert into clientes (nombre,apellido,estado_civil,cuit,direccion,telefono,email,comentarios) values('Franco','Sanchez','DIVORCIADO','240534908','Bulnes 321','22223333','francosanchez@gmail.com','deja propina');
insert into clientes (nombre,apellido,estado_civil,cuit,direccion,telefono,email,comentarios) values('Tomas','Albornoz','CASADO','2242250808','Peru 1254','33334444','tomasalbornoz@gmail.com','cliente frecuente');

insert into facturas (letra,numero, fecha, monto,forma_de_pago,id_cliente) values('A',100,curdate(),45.20,'EFECTIVO',1);
insert into facturas (letra,numero, fecha, monto,forma_de_pago,id_cliente) values('B',200,curdate(),49.99,'CHEQUE',2);
insert into facturas (letra,numero, fecha, monto,forma_de_pago,id_cliente) values('A',300,curdate(),199.99,'TARJETA',3);
insert into facturas (letra,numero, fecha, monto,forma_de_pago,id_cliente) values('C',400,curdate(),5.99,'EFECTIVO',4);
insert into facturas (letra,numero, fecha, monto,forma_de_pago,id_cliente) values('A',500,curdate(),99.99,'DEBITO',5);

insert into articulos (descripcion,rubro, costo, precio,stock, stock_minimo,stock_maximo) values('Leche','LACTEOS',99.99,129.99,100,50,150);
insert into articulos (descripcion,rubro, costo, precio,stock, stock_minimo,stock_maximo) values('Pan Francés','PANADERIA',89.99,139.99,20,20,35);
insert into articulos (descripcion,rubro, costo, precio,stock, stock_minimo,stock_maximo) values('Picada','FIAMBRES',79.99,145.99,55,50,65);
insert into articulos (descripcion,rubro, costo, precio,stock, stock_minimo,stock_maximo) values('Limpiavidrios','LIMPIEZA',69.99,85.15,75,50,100);
insert into articulos (descripcion,rubro, costo, precio,stock, stock_minimo,stock_maximo) values('Cerveza','BEBIDAS',59.99,69.50,88,44,88);


insert into detalles (id_factura, id_articulo, cantidad, precio_unitario) values(10,1,10,695.00);
insert into detalles (id_factura, id_articulo, cantidad, precio_unitario) values(11,2,2,279.98);
insert into detalles (id_factura, id_articulo, cantidad, precio_unitario) values(12,3,1,145.99);
insert into detalles (id_factura, id_articulo, cantidad, precio_unitario) values(13,4,3,255.45);
insert into detalles (id_factura, id_articulo, cantidad, precio_unitario) values(14,17,10,1299.90);



insert into clientes(nombre, apellido, estado_civil, cuit, direccion, telefono, email) values 
('Mariano','Fernandez','SOLTERO', '3798463824','Ramon Castillo 123', '73748499', 'marianfernandez@gmail.com'),
('Julia','Ortiz','CASADO','209393832','Calle 12', '1183739257', 'jortiz13@hotmail.com'),
('Ramon', 'Torres','VIUDO','23139483', 'Loyola 1187', '11837482', 'ramontorres@gmail.com'),
('Pepito','Perez','DIVORCIADO','30879832889','Diaz Velez 1','1174827','pepito193@gmail.com'),
('Juana', 'Perez', 'SOLTERO', '309482732', 'Calle real 33', '11387983', 'juanitaperez@gmail.com');

insert into articulos(descripcion, rubro, costo, precio, stock, stock_minimo, stock_maximo) values
('Leche Sancor 1 lt','LACTEOS', 70, 90, 182, 0, null),
('Cremona x 250g','PANADERIA', 30, 50, 5, 0, 10),
('Procenex pisos 1 lt','LIMPIEZA', 170, 250, 17, 0, null),
('Tapa de asado x kg','CARNICERIA', 670, 1000, 22, 0, 50),
('Mortadela x 100g', 'FIAMBRES', 120, 150, 300, 0, null);

insert into facturas(letra, numero, fecha, monto, forma_de_pago, id_cliente) values 
('B', 288, curdate(), 140,'EFECTIVO', 3),
('B', 388, curdate(), 250,'EFECTIVO', 1),
('A', 158, curdate(), 3000, 'TARJETA', 4),
('A', 898, curdate(), 190, 'EFECTIVO', 2),
('B', 188, curdate(), 1250, 'EFECTIVO', 1);


insert into detalles(id_factura,id_articulo,cantidad,precio_unitario) values 
(31, 1, 1, 70),
(31, 2, 1, 50),
(32, 3, 1, 250),
(33, 4, 3, 1000),
(30, 2, 2, 50),
(30, 1, 1, 90);

select * from facturas;


insert into clientes (nombre,apellido,estado_civil,cuit,direccion,telefono,email,comentarios) values
('Marta','Gomez','SOLTERO',4210244,'Av siempre viva 321','4865498','Martita@gmail.com','Hola soy Marta Gomez'),
('Maite','Garcia','CASADO',586923,'Lopez de vega 153','4562033','MaiteCrisis@hotmail.com','Hola soy Maite'),
('Martin','Camacho','VIUDO',256332,'Pasco 1233','4020896','MartinEze@gmail.com','Hola soy Camacho'),
('Ermelinda','Yaccuzzi','DIVORCIADO',362517,'AV.Entre Rios 1633','46597946','YaccuErme@gmail.com','Hola soy Ermelinda'),
('Jose','Santos','SOLTERO',516355,'Gorriti 4564','JosePedrol@gmail.com','45613975','Hola soy Santos');

insert into articulos(descripcion,rubro,costo,precio,stock,stock_minimo,stock_maximo) VALUES
('Coca Cola','BEBIDAS',50,250,100,0,500),
('Jamon Natural 42','FIAMBRES',10,130,20,0,200),
('Pan Lactal','PANADERIA',5,300,20,2,100), 
('Detergente','LIMPIEZA ',200,500,56,10,1000),
('Chorizo','CARNICERIA',150,300,15,0,500);

INSERT into facturas(letra,numero,fecha,monto,forma_de_pago,id_cliente) VALUES
('A',35789,'2022/05/20',1000,'EFECTIVO',2),
('A',35159,'2021/10/12',2000,'EFECTIVO',5),
('A',35147,'2020/08/30',5000,'TARJETA',3),
('A',35963,'2019/04/18',4500,'DEBITO',1),
('A',35322,'2020/11/27',3500,'CHEQUE',4);

INSERT into detalles(id_factura,id_articulo,cantidad,precio_unitario)VALUES
(1,51,50,5000),
(5,54,10,200),
(4,52,30,6000),
(3,53,400,2000),
(1,52,150,3500);

/* Carga de articulos */

INSERT INTO negocio.articulos (descripcion, rubro, costo, precio, stock, stock_minimo, stock_maximo) VALUES ('Dulce de Leche', 'LACTEOS', 430, 500, 25, 5, 50);
INSERT INTO negocio.articulos (descripcion, rubro, costo, precio, stock, stock_minimo, stock_maximo) VALUES ('Gini 1.25 lts', 'BEBIDAS', 100, 150, 12, 5, 30);
INSERT INTO negocio.articulos (descripcion, rubro, costo, precio, stock, stock_minimo, stock_maximo) VALUES ('Manaos Cola 2.25', 'BEBIDAS', 150, 200, 40, 20, 100);
INSERT INTO negocio.articulos (descripcion, rubro, costo, precio, stock, stock_minimo, stock_maximo) VALUES ('Cuadril', 'CARNICERIA', 600, 900, 300, 50, 300);
INSERT INTO negocio.articulos (descripcion, rubro, costo, precio, stock, stock_minimo, stock_maximo) VALUES ('Ariel 3Lts', 'LIMPIEZA', 750, 1150, 10, 5, 20);

/* carga de clientes */

INSERT INTO negocio.clientes (nombre, apellido, estado_civil, cuit, direccion, telefono, email, comentarios) VALUES ('Javier', 'Suarez', 'CASADO', '0243350728', 'Condarco 215', '1165067007', 'jsuarez@sion.com', 'es un buen cliente');
INSERT INTO negocio.clientes (nombre, apellido, estado_civil, cuit, direccion, telefono, email) VALUES ('Leonardo', 'Sbaraglia', 'SOLTERO', '0193752408', 'Madame Curie 1940', '42275848', 'lsbaraglia@gmail.com');
INSERT INTO negocio.clientes (nombre, apellido, estado_civil, cuit, direccion, telefono, email) VALUES ('Violeta', 'Rivas', 'CASADO', '7142572483', 'Mejor Vida 434', '4666-3533', 'violetar@hotmail.com');
INSERT INTO negocio.clientes (nombre, apellido, estado_civil, cuit, direccion, telefono, email) VALUES ('Juan', 'Petruchi', 'VIUDO', '3045132439', 'Medrano 520', '1161632748', 'jcpetrucchi@infovia.com.ar');
INSERT INTO negocio.clientes (nombre, apellido, estado_civil, cuit, direccion, telefono, email) VALUES ('Claudia', 'Villafañe', 'VIUDO', '7816345924', 'Las Violetas 45', '1121658729', 'lamujerdeldiez@hotmail.com');

/* carga de facturas */

INSERT INTO negocio.facturas (letra, numero, fecha, monto, forma_de_pago, id_cliente) VALUES ('B', 1, current_date(), 2250, 'EFECTIVO', 1);
INSERT INTO negocio.facturas (letra, numero, fecha, monto, forma_de_pago, id_cliente) VALUES ('A', 10, current_date(), 2420, 'CHEQUE', 2);
INSERT INTO negocio.facturas (letra, numero, fecha, monto, forma_de_pago, id_cliente) VALUES ('B', 20, current_date(), 1150, 'TARJETA', 3);

/* carga de detalle */

INSERT INTO negocio.detalles (id_factura, id_articulo, cantidad, precio_unitario) VALUES (1, 1, 1, 500);
INSERT INTO negocio.detalles (id_factura, id_articulo, cantidad, precio_unitario) VALUES (1, 4, 1, 1350);
INSERT INTO negocio.detalles (id_factura, id_articulo, cantidad, precio_unitario) VALUES (1, 3, 2, 400);
INSERT INTO negocio.detalles (id_factura, id_articulo, cantidad, precio_unitario) VALUES (2, 2, 1, 150);
INSERT INTO negocio.detalles (id_factura, id_articulo, cantidad, precio_unitario) VALUES (2, 30, 1, 200);
INSERT INTO negocio.detalles (id_factura, id_articulo, cantidad, precio_unitario) VALUES (2, 40, 2, 2070);
INSERT INTO negocio.detalles (id_factura, id_articulo, cantidad, precio_unitario) VALUES (3, 50, 1, 1150);


INSERT INTO negocio.articulos (descripcion, rubro, costo, precio, stock, stock_minimo, stock_maximo) VALUES ('leche', 'lacteos', 100, 150, 1000, 300, 700);
INSERT INTO negocio.articulos (descripcion, rubro, costo, precio, stock, stock_minimo, stock_maximo) VALUES ('coca-cola', 'bebidas', 120, 180, 1500, 600, 900);
INSERT INTO negocio.articulos (descripcion, rubro, costo, precio, stock, stock_minimo, stock_maximo) VALUES ('jamon', 'fiambres', 87, 100, 500, 200, 300);
INSERT INTO negocio.articulos (descripcion, rubro, costo, precio, stock, stock_minimo, stock_maximo) VALUES ('antitranspirante', 'personal', 80, 100, 200, 50, 150);
INSERT INTO negocio.articulos (descripcion, rubro, costo, precio, stock, stock_minimo, stock_maximo) VALUES ('hamburguesa', 'carniceria', 450, 500, 200, 50, 100);

INSERT INTO negocio.clientes (nombre, apellido, estado_civil, cuit, direccion, telefono, email, comentarios) VALUES ('roberto', 'castañeda', 'SOLTERO', '20364486814', 'laprida123', '47161587', 'rb@gmail.com', 'gracias');
INSERT INTO negocio.clientes (nombre, apellido, estado_civil, cuit, direccion, telefono, email, comentarios) VALUES ('carla', 'mosqueda', 'DIVORCIADO', '20365093364', 'lage344', '45674466', 'cl@gmail.com', 'gracias');
INSERT INTO negocio.clientes (nombre, apellido, estado_civil, cuit, direccion, telefono, email, comentarios) VALUES ('ricardo', 'funes', 'CASADO', '20354446554', 'españa345', '47591532', 'richard@gamil.com', 'gracias');
INSERT INTO negocio.clientes (nombre, apellido, estado_civil, cuit, direccion, telefono, email, comentarios) VALUES ('lautaro', 'dupar', 'SOLTERO', '20375984764', 'seneca1762', '47596666', 'lp@gmail.com', 'gracias');
INSERT INTO negocio.clientes (nombre, apellido, estado_civil, cuit, direccion, telefono, email, comentarios) VALUES ('florencia', 'montalvo', 'SOLTERO', '365023474', 'medrano162', '47162089', 'fl@gmail.com', 'gracias');

INSERT INTO negocio.facturas (letra, numero, fecha, monto, forma_de_pago, id_cliente) VALUES ('c', 901, '22/04/04', 3000, 'EFECTIVO',1);
INSERT INTO negocio.facturas (letra, numero, fecha, monto, forma_de_pago, id_cliente) VALUES ('c', 902, '22/04/04', 1500, 'DEBITO',2);
INSERT INTO negocio.facturas (letra, numero, fecha, monto, forma_de_pago, id_cliente) VALUES ('c', 903, '22/04/04', 1000, 'DEBITO',3);
INSERT INTO negocio.facturas (letra, numero, fecha, monto, forma_de_pago, id_cliente) VALUES ('c', 904, '22/04/04', 5000, 'TARJETA',4);
INSERT INTO negocio.facturas (letra, numero, fecha, monto, forma_de_pago, id_cliente) VALUES ('c', 905, '22/04/04', 10000, 'CHEQUE',5);

INSERT INTO negocio.detalles (id_factura, id_articulo, cantidad, precio_unitario) VALUES (01, 01, 2, 450);
INSERT INTO negocio.detalles (id_factura, id_articulo, cantidad, precio_unitario) VALUES (02, 02, 100, 3000);
INSERT INTO negocio.detalles (id_factura, id_articulo, cantidad, precio_unitario) VALUES (03, 03, 500, 4000);
INSERT INTO negocio.detalles (id_factura, id_articulo, cantidad, precio_unitario) VALUES (04, 04, 1000, 5000);
INSERT INTO negocio.detalles (id_factura, id_articulo, cantidad, precio_unitario) VALUES (05, 05, 100, 1500);

select * from articulos;