use negocio;
show tables;

-- consulta de catalogo de indices
select * from information_schema.INNODB_SYS_INDEXES;
select * from information_schema.INNODB_SYS_TABLES;

select i.INDEX_ID , i.NAME, t.TABLE_ID, t.NAME 
	from information_schema.INNODB_SYS_INDEXES i
	join information_schema.INNODB_SYS_TABLES t 
	on i.TABLE_ID = t.TABLE_ID
	where t.NAME like 'negocio%';

CREATE INDEX I_Clientes_Nombre ON clientes(nombre);
create index I_Clientes_Apellido_Nombre on clientes(apellido,nombre);
drop index I_Clientes_Nombre on clientes;
alter table facturas add index I_Facturas_Fecha (fecha);


select * from information_schema.TABLES t;

drop index U_clientes_cuit on clientes;
-- Indices de Unicidad
alter table clientes
    add constraint U_clientes_cuit
    unique(cuit);
    
 create unique index I_Clientes_Cuit
 	on clientes(cuit);
 	
 -- Crear un indice de unicidad para los campos descripcion y rubro de la 
 -- tabla articulos.
 
 
 
 
 
 