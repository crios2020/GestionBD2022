drop table if exists libros;
 
create table libros(
	codigo integer,
	titulo text,
	autor text,
	editorial text,
	primary key (codigo)
);

insert into libros (titulo,autor,editorial)
  values('El aleph','Borges','Planeta');
  
insert into libros (titulo,autor,editorial)
  values('Martin Fierro','Jose Hernandez','Paidos'); 
  
select codigo, titulo, autor, editorial from libros;

pragma table_info('libros');