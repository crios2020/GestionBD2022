-- MySQL dump 10.19  Distrib 10.3.34-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: 127.0.0.1    Database: negocio
-- ------------------------------------------------------
-- Server version	10.4.24-MariaDB

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `articulos`
--

DROP TABLE IF EXISTS `articulos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `articulos` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `descripcion` varchar(50) NOT NULL,
  `rubro` enum('LACTEOS','PANADERIA','LIMPIEZA','PERSONAL','FIAMBRES','CARNICERIA','BEBIDAS') DEFAULT NULL,
  `costo` double DEFAULT NULL,
  `precio` double DEFAULT NULL,
  `stock` int(11) DEFAULT NULL,
  `stock_minimo` int(11) DEFAULT NULL,
  `stock_maximo` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  CONSTRAINT `CK_articulos_costo` CHECK (`costo` >= 0),
  CONSTRAINT `CK_articulos_precio` CHECK (`precio` >= `costo`),
  CONSTRAINT `CK_articulos_stock` CHECK (`stock` >= 0),
  CONSTRAINT `CK_articulos_stock_minimo` CHECK (`stock_minimo` >= 0),
  CONSTRAINT `CK_articulos_stock_maximo` CHECK (`stock_maximo` >= `stock_minimo`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `articulos`
--

LOCK TABLES `articulos` WRITE;
/*!40000 ALTER TABLE `articulos` DISABLE KEYS */;
INSERT INTO `articulos` VALUES (3,'Escoba','LIMPIEZA',45,65,34,43,76),(4,'Leche','LACTEOS',17,27,9,15,27),(5,'Fernet','BEBIDAS',57,156,93,152,270),(6,'Escoba','LIMPIEZA',45,65,34,43,76),(7,'Coca Cola','BEBIDAS',50,200,100,0,500),(8,'Coca Cola','BEBIDAS',50,200,100,0,500),(9,'Coca Cola','BEBIDAS',50,200,100,0,500),(10,'leche','LACTEOS',100,150,1000,300,700),(11,'coca-cola','BEBIDAS',120,180,1500,600,900),(12,'fernet','BEBIDAS',700,1000,1000,300,700),(13,'hamburguesa','CARNICERIA',100,150,1000,300,700),(15,'VINO PATERO BIDON 5L','BEBIDAS',152,250,15,1,20),(16,'FERNET BRANCA','BEBIDAS',152,250,15,1,20),(17,'VINO PATERO BIDON 5L','BEBIDAS',152,250,15,1,20),(18,'FERNET BRANCA','BEBIDAS',152,250,15,1,20),(19,'VINO PATERO BIDON 5L','BEBIDAS',152,250,15,1,20),(20,'FERNET BRANCA','BEBIDAS',152,250,15,1,20),(21,'VINO PATERO BIDON 5L','BEBIDAS',152,250,15,1,20),(22,'FERNET BRANCA','BEBIDAS',152,250,15,1,20),(23,'VINO PATERO BIDON 5L','BEBIDAS',152,250,15,1,20),(24,'FERNET BRANCA','BEBIDAS',152,250,15,1,20),(25,'VINO PATERO BIDON 5L','BEBIDAS',152,250,15,1,20),(26,'FERNET BRANCA','BEBIDAS',152,250,15,1,20);
/*!40000 ALTER TABLE `articulos` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `clientes`
--

DROP TABLE IF EXISTS `clientes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `clientes` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nombre` varchar(25) NOT NULL,
  `apellido` varchar(25) NOT NULL,
  `estado_civil` enum('SOLTERO','CASADO','VIUDO','DIVORCIADO') DEFAULT NULL,
  `cuit` char(11) DEFAULT NULL,
  `direccion` varchar(100) DEFAULT NULL,
  `telefono` varchar(20) DEFAULT NULL,
  `email` varchar(40) DEFAULT NULL,
  `comentarios` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `U_clientes_cuit` (`cuit`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `clientes`
--

LOCK TABLES `clientes` WRITE;
/*!40000 ALTER TABLE `clientes` DISABLE KEYS */;
INSERT INTO `clientes` VALUES (1,'ana','sosa','CASADO','291','lima 222','0303456','anasosa@gmail.com',''),(2,'diego','soto','CASADO','292','lima 122','0303457','diego@gmail.com',''),(3,'malena','segovia','SOLTERO','293','lima 121','0303459','male@gmail.com',''),(4,'Jose','Joseito','VIUDO','294','lavalle 122','5555555','jose@gmail.com','');
/*!40000 ALTER TABLE `clientes` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `detalles`
--

DROP TABLE IF EXISTS `detalles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `detalles` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `id_factura` int(11) NOT NULL,
  `id_articulo` int(11) NOT NULL,
  `cantidad` int(11) NOT NULL,
  `precio_unitario` double DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `U_detalles_facturas_articulos` (`id_factura`,`id_articulo`),
  KEY `FK_detalles_articulos` (`id_articulo`),
  CONSTRAINT `FK_detalles_articulos` FOREIGN KEY (`id_articulo`) REFERENCES `articulos` (`id`),
  CONSTRAINT `FK_detalles_facturas` FOREIGN KEY (`id_factura`) REFERENCES `facturas` (`id`),
  CONSTRAINT `CK_detalles_cantidad` CHECK (`cantidad` >= 0),
  CONSTRAINT `CK_detalles_precio_unitario` CHECK (`precio_unitario` >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `detalles`
--

LOCK TABLES `detalles` WRITE;
/*!40000 ALTER TABLE `detalles` DISABLE KEYS */;
/*!40000 ALTER TABLE `detalles` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `facturas`
--

DROP TABLE IF EXISTS `facturas`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `facturas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `letra` char(1) NOT NULL,
  `numero` int(11) NOT NULL,
  `fecha` date DEFAULT NULL,
  `monto` double DEFAULT NULL,
  `forma_de_pago` enum('EFECTIVO','TARJETA','DEBITO','CHEQUE') DEFAULT NULL,
  `id_cliente` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `U_facturas_letra_numero` (`letra`,`numero`),
  KEY `FK_facturas_clientes` (`id_cliente`),
  CONSTRAINT `FK_facturas_clientes` FOREIGN KEY (`id_cliente`) REFERENCES `clientes` (`id`),
  CONSTRAINT `CK_facturas_monto` CHECK (`monto` >= 0)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `facturas`
--

LOCK TABLES `facturas` WRITE;
/*!40000 ALTER TABLE `facturas` DISABLE KEYS */;
/*!40000 ALTER TABLE `facturas` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-06-13 15:50:26
