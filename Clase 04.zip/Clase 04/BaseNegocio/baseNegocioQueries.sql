-- Que clientes (nombre, apellido) compraron bebidas?

-- Que articulos(descripción, rubro, precio) compro el cliente 'Juan' 'Perez'

-- Lista de articulos a reponer + cantidad y costo de la reposición?

-- Cuanto es el monto total vendido al cliente 'Juan', 'Perez'?

-- Total facturado por mes

-- Total facturado por rubro


