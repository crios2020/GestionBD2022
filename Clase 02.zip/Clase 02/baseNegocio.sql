-- Base datos negocio para toda la especialización web.
select version();
drop database if exists negocio;
create database negocio;
use negocio;
drop table if exists clientes;
create table clientes(
    id int AUTO_INCREMENT PRIMARY KEY,
    nombre varchar(25) not null,
    apellido varchar(25) not null,
    estado_civil enum('SOLTERO','CASADO','VIUDO','DIVORCIADO'),
    cuit char(11),
    direccion varchar(100),
    telefono varchar(20),
    email varchar(40),
    comentarios varchar(255)
);

create table facturas(
    id int AUTO_INCREMENT PRIMARY KEY,
    letra char(1) not null,
    numero int not null,
    fecha date,
    monto double,
    forma_de_pago enum('EFECTIVO','TARJETA','DEBITO','CHEQUE')
);

