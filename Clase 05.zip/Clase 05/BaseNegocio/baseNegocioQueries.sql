use negocio;
show tables;

-- Que clientes (nombre, apellido) compraron bebidas?
select DISTINCT c.nombre, c.apellido
	from clientes c join facturas f on c.id =f.id_cliente 
	join detalles d on f.id =d.id_factura 
	join articulos a on d.id_articulo =a.id 
	where a.rubro ="BEBIDAS";

-- Que articulos(descripción, rubro, precio) compro el cliente 'Juan' 'Perez'
select * from clientes;
update clientes set nombre='Juan', apellido ='Perez' where id=1;
select DISTINCT a.descripcion, a.rubro, a.precio 
	from clientes c join facturas f on c.id =f.id_cliente 
	join detalles d on f.id =d.id_factura 
	join articulos a on d.id_articulo =a.id
	where c.nombre ='Juan' and apellido ='Perez';

update articulos set stock=stock-1;
-- Lista de articulos a reponer + cantidad y costo de la reposición?
select sum(costo*(stock_maximo-stock)) costo from articulos where stock<stock_minimo;
SELECT id,descripcion ,rubro, costo, precio, stock, stock_minimo, stock_maximo,
		stock_maximo-stock cantidad_a_reponer, costo*(stock_maximo-stock) costo_de_reposición
from articulos where stock<stock_minimo;

-- Cuanto es el monto total vendido al cliente 'Juan', 'Perez'?
select sum(f.monto) total 
from clientes c join facturas f on c.id =f.id_cliente 
	join detalles d on f.id =d.id_factura 
	join articulos a on d.id_articulo =a.id
	where c.nombre ='Juan' and apellido ='Perez';

select sum(d.precio_unitario*d.cantidad) total 
from clientes c join facturas f on c.id =f.id_cliente 
	join detalles d on f.id =d.id_factura 
	join articulos a on d.id_articulo =a.id
	where c.nombre ='Juan' and apellido ='Perez';


-- Total facturado por mes
select CONCAT(YEAR(f.fecha),'/',MONTH(f.fecha)) mes, sum(f.monto) total
	from facturas f group by CONCAT(YEAR(f.fecha),'/',MONTH(f.fecha)); 

select CONCAT(YEAR(f.fecha),'/',MONTH(f.fecha)) mes, round(sum(d.cantidad*d.precio_unitario),2) total
	from facturas f join detalles d on f.id =d.id_factura  
	group by CONCAT(YEAR(f.fecha),'/',MONTH(f.fecha)); 

-- Total facturado por rubro
select a.rubro, round(sum(d.cantidad*d.precio_unitario),2) total
	from facturas f join detalles d on f.id =d.id_factura
	join articulos a on d.id_articulo = a.id
	GROUP by a.rubro;



