show databases;
use negocio;

-- Objetos vistas
-- La vista se crea a partir de una query y se ve como una tabla

-- creamos una vista
create view vista_ejemplo
	as 
		select * from clientes;
	
show databases;		-- consulta al catalogo de base de datos (schemas)  	MySQL
select * from information_schema.SCHEMATA s;	
select s.SCHEMA_NAME Base_de_datos from information_schema.SCHEMATA s;

show tables;		-- consulta al catalogo de tablas						MySQL
select * from information_schema.TABLES t;
select t.TABLE_NAME tabla from information_schema.TABLES t where TABLE_SCHEMA ='negocio';


select * from vista_ejemplo;

-- Consulta de catalogo de vistas
SELECT * from information_schema.VIEWS v;
select TABLE_NAME tabla from information_schema.VIEWS v where TABLE_SCHEMA='negocio';

-- borramos una vista
drop view if exists vista_ejemplo;

describe clientes;
describe facturas;
describe detalles;
describe articulos;

-- creamos una vista general
create view vista_general as
	select c.id id_cliente, CONCAT(c.nombre, ' ', c.apellido) nombre_apellido, 
	c.estado_civil, c.cuit, c.direccion, c.telefono, c.email, c.comentarios, 
	f.id id_factura, f.letra, f.numero, f.fecha, f.monto, f.forma_de_pago, 
	d.id id_detalle, d.cantidad, d.precio_unitario, a.id id_articulo, a.descripcion,
	a.rubro, a.costo, a.precio, a.stock, a.stock_minimo, a.stock_maximo
	from clientes c join facturas f on c.id = f.id_cliente
	join detalles d on f.id =d.id_factura 
	join articulos a on d.id_articulo = a.id;

select * from vista_general;

-- Que clientes (nombre, apellido) compraron bebidas?
select DISTINCT nombre_apellido from vista_general where rubro='BEBIDAS';
-- Que articulos(descripción, rubro, precio) compro el cliente 'Juan' 'Perez'
select DISTINCT descripcion, rubro, precio, stock from vista_general 
where nombre_apellido='Juan Perez';
-- Lista de articulos a reponer + cantidad y costo de la reposición?
-- select sum(costo*(stock_maximo-stock)) costo, stock_maximo - stock cantidad_reponer
-- from articulos where stock<stock_minimo;
SELECT id,descripcion ,rubro, costo, precio, stock, stock_minimo, stock_maximo,
		stock_maximo-stock cantidad_a_reponer, costo*(stock_maximo-stock) costo_de_reposición
from articulos where stock<stock_minimo;
-- Cuanto es el monto total vendido al cliente 'Juan', 'Perez'?
select sum(monto) total from vista_general where nombre_apellido='Juan Perez';
-- Total facturado por mes
select concat(year(fecha),'/',month(fecha)) mes, 
	sum(cantidad*precio_unitario) total
	from vista_general
	group by concat(year(fecha),'/',month(fecha));

-- Total facturado por rubro
select rubro, sum(cantidad*precio_unitario) total
	from vista_general
	group by rubro;

-- Total $ a reponer por rubro?




