-- Clase 8 Procedimientos Almacenados - store procedure
select version();
use negocio_2022;
show databases;
show tables;
select version();
SELECT * from information_schema.ROUTINES where SPECIFIC_NAME like 'SP_%';

drop procedure if exists SP_test;
delimiter //
create procedure SP_test()
	begin
		select 'Hola';
	end;
// delimiter ;

call SP_test;


-- creamos stores de los catalogos de objetos
drop procedure if exists SP_procedures;
delimiter //
create procedure SP_procedures()
	begin
		SELECT * from information_schema.ROUTINES where SPECIFIC_NAME like 'SP_%';
	end;
// delimiter ;

drop procedure if exists SP_vistas;
delimiter //
create procedure SP_vistas()
	begin
		select t.TABLE_NAME tabla 
		from information_schema.TABLES t 
		where TABLE_SCHEMA ='negocio';
	end;
// delimiter ;

call SP_procedures;
call SP_vistas;





